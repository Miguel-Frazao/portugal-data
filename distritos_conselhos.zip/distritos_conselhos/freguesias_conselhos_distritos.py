from bs4 import BeautifulSoup
import requests, threading, queue, json, time

def get_req(url):
    try:
        req = requests.get(url, timeout=2)
        return req
    except Exception as e:
        print('retrying {}. Exception: {}'.format(url, e))
        return get_req(url)
            
base_url = 'http://www.codigo-postal.pt'
req = get_req(base_url)
soup = BeautifulSoup(req.text, 'html.parser')
distritos_html = soup.select('.list-unstyled a')
distritos = (i.text for i in distritos_html)
distritos_links = ('{}{}'.format(base_url, i['href']) for i in distritos_html)
distritos_zip = zip(distritos, distritos_links)
conc_dists = {}
fregs_conc_dists = {}
for dist, dist_link in distritos_zip:
    conc_dists[dist] = []
    fregs_conc_dists[dist] = {}
    req = get_req(dist_link)
    print('getting dist links', dist_link)
    soup = BeautifulSoup(req.text, 'html.parser')
    concelhos_html = soup.select('.list-unstyled a')
    concelhos = sorted({i.text: '{}{}'.format(base_url, i['href']) for i in concelhos_html}.items())
    for conc, conc_link in concelhos:
        conc_dists[dist].append(conc)
        fregs_conc_dists[dist][conc] = []
        print('getting conc links', conc_link)
        req = get_req(conc_link)
        soup = BeautifulSoup(req.text, 'html.parser')
        fregs_html = soup.select('.list-unstyled a')
        fregs = sorted((i.text for i in fregs_html))
        for freg in fregs:
            fregs_conc_dists[dist][conc].append(freg)

with open('concelhos_distritos_unicode.json', 'w') as f:
    f.write(json.dumps(conc_dists, sort_keys=True, indent=4))
with open('concelhos_distritos_utf8.json', 'w') as f:
    f.write(json.dumps(conc_dists, sort_keys=True, indent=4, ensure_ascii=False))
with open('freguesias_concelhos_distritos_unicode.json', 'w') as f:
    f.write(json.dumps(fregs_conc_dists, sort_keys=True, indent=4))
with open('freguesias_concelhos_distritos_utf8.json', 'w') as f:
    f.write(json.dumps(fregs_conc_dists, sort_keys=True, indent=4, ensure_ascii=False))
